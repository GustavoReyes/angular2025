export class Task {
  id: number;
  title: string;
  description: string;
  infoTask?: string;

  constructor(id: number, title: string, description: string, infoTask?: string) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.infoTask = infoTask;
  }
}
